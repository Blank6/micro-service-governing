package org.springcloud.eureka.server.filter;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.servlet.Filter;

@Configuration
public class FilterConfig {

    @Bean
    public FilterRegistrationBean registryFilterBean() {
        FilterRegistrationBean registrationBean = new FilterRegistrationBean();
        registrationBean.setFilter(new RegistryFilter());
        registrationBean.addUrlPatterns("/eureka/apps/*");
        registrationBean.addInitParameter("paramName", "paramValue");
        registrationBean.setName("registryFilter");
        registrationBean.setOrder(1);
        return registrationBean;
    }

//    @Bean
//    public Filter registryFilter() {
//        return new RegistryFilter();
//    }
}
