package org.springcloud.eureka.server.filter;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springcloud.eureka.server.Service.ValidService;
//import org.springcloud.eureka.server.entity.response.RespEntity;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpEntity;
//import org.springframework.http.HttpHeaders;
//import org.springframework.http.MediaType;
//import org.springframework.web.context.support.SpringBeanAutowiringSupport;
//
import javax.servlet.*;
import javax.servlet.FilterConfig;
import java.io.IOException;
//import javax.servlet.FilterConfig;
//import java.io.IOException;
//

public class RegistryFilter implements Filter {


    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {

    }

    @Override
    public void destroy() {

    }
}



//public class RegistryFilter implements Filter {
//
//    protected final Logger logger = LoggerFactory.getLogger(getClass());
//
//    @Autowired
//    ValidService validService;
//
//    @Override
//    public void init(FilterConfig filterConfig) throws ServletException {
//        //logger.info("***************" + getClass() + " init");
//        /**
//         * 如果想要在Filter中执行Services，restTemplate方法，要在初始化Filter中执行如下方法（因为Filter执行顺序提前与Services）
//         */
//        SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this, filterConfig.getServletContext());
//    }
//
//    @Override
//    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
//        //logger.info("***************" + getClass() + " doFilter ");
//        logger.info("获取请求信息：" + request.getContentType());
//        logger.info(request.getParameterNames().toString());
//        logger.info(request.getParameter("instanceId"));
//        HttpHeaders headers = new HttpHeaders();
//        MediaType type = MediaType.parseMediaType("application/json; charset=UTF-8");
//        headers.setContentType(type);
//        headers.add("Accept", MediaType.APPLICATION_JSON.toString());
//        HttpEntity fromEntity = new HttpEntity(null, headers);
//
//        /**
//         * 验证
//         */
//        logger.info("Filter****************发送验证请求到治理中心*******************");
//        RespEntity result = validService.validClient("http://localhost:30000/validApplication", fromEntity);
//        logger.info("验证结果：" + result.toString());
//
//        try{
//            if (result.getErrorCode() != 200) {
//                logger.info(result.toString());
//                return ;
//            }
//        } catch (Throwable throwable) {
//            logger.error("validated error", throwable);
//        }
//        chain.doFilter(request, response);
//    }
//
//    @Override
//    public void destroy() {
//        logger.info("***************" + getClass() + " destroy");
//    }
//
//}
